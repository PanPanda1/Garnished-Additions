
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.garnishedadditions.fluid.types.EtherealSyrupFluidType;
import net.mcreator.garnishedadditions.fluid.types.EtherealSapFluidType;
import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

public class GarnishedAdditionsModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, GarnishedAdditionsMod.MODID);
	public static final RegistryObject<FluidType> ETHEREAL_SAP_TYPE = REGISTRY.register("ethereal_sap", () -> new EtherealSapFluidType());
	public static final RegistryObject<FluidType> ETHEREAL_SYRUP_TYPE = REGISTRY.register("ethereal_syrup", () -> new EtherealSyrupFluidType());
}
