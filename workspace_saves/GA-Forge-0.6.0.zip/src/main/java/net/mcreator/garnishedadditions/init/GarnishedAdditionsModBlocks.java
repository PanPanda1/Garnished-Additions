
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.garnishedadditions.block.StrippedEtherealWoodBlock;
import net.mcreator.garnishedadditions.block.StrippedEtherealLogBlock;
import net.mcreator.garnishedadditions.block.RootedEndStoneBlock;
import net.mcreator.garnishedadditions.block.NutiumBlockBlock;
import net.mcreator.garnishedadditions.block.LethalLianaBottomBlock;
import net.mcreator.garnishedadditions.block.LethalLianaBlock;
import net.mcreator.garnishedadditions.block.HazardousHyphaeBottomBlock;
import net.mcreator.garnishedadditions.block.HazardousHyphaeBlock;
import net.mcreator.garnishedadditions.block.EtherealWoodBlock;
import net.mcreator.garnishedadditions.block.EtherealTrapdoorBlock;
import net.mcreator.garnishedadditions.block.EtherealSyrupBlock;
import net.mcreator.garnishedadditions.block.EtherealStairsBlock;
import net.mcreator.garnishedadditions.block.EtherealSlabBlock;
import net.mcreator.garnishedadditions.block.EtherealSapBlock;
import net.mcreator.garnishedadditions.block.EtherealPressurePlateBlock;
import net.mcreator.garnishedadditions.block.EtherealPlanksBlock;
import net.mcreator.garnishedadditions.block.EtherealLogBlock;
import net.mcreator.garnishedadditions.block.EtherealLeavesBlock;
import net.mcreator.garnishedadditions.block.EtherealGrowthBlock;
import net.mcreator.garnishedadditions.block.EtherealFenceGateBlock;
import net.mcreator.garnishedadditions.block.EtherealFenceBlock;
import net.mcreator.garnishedadditions.block.EtherealDoorBlock;
import net.mcreator.garnishedadditions.block.EtherealCakeBlock;
import net.mcreator.garnishedadditions.block.EtherealCake6Block;
import net.mcreator.garnishedadditions.block.EtherealCake5Block;
import net.mcreator.garnishedadditions.block.EtherealCake4Block;
import net.mcreator.garnishedadditions.block.EtherealCake3Block;
import net.mcreator.garnishedadditions.block.EtherealCake2Block;
import net.mcreator.garnishedadditions.block.EtherealCake1Block;
import net.mcreator.garnishedadditions.block.EtherealButtonBlock;
import net.mcreator.garnishedadditions.block.EtherealBushStage3Block;
import net.mcreator.garnishedadditions.block.EtherealBushStage2Block;
import net.mcreator.garnishedadditions.block.EtherealBushStage1Block;
import net.mcreator.garnishedadditions.block.EtherealBushStage0Block;
import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

public class GarnishedAdditionsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, GarnishedAdditionsMod.MODID);
	public static final RegistryObject<Block> NUTIUM_BLOCK = REGISTRY.register("nutium_block", () -> new NutiumBlockBlock());
	public static final RegistryObject<Block> ETHEREAL_LOG = REGISTRY.register("ethereal_log", () -> new EtherealLogBlock());
	public static final RegistryObject<Block> ETHEREAL_WOOD = REGISTRY.register("ethereal_wood", () -> new EtherealWoodBlock());
	public static final RegistryObject<Block> STRIPPED_ETHEREAL_LOG = REGISTRY.register("stripped_ethereal_log", () -> new StrippedEtherealLogBlock());
	public static final RegistryObject<Block> STRIPPED_ETHEREAL_WOOD = REGISTRY.register("stripped_ethereal_wood", () -> new StrippedEtherealWoodBlock());
	public static final RegistryObject<Block> ETHEREAL_PLANKS = REGISTRY.register("ethereal_planks", () -> new EtherealPlanksBlock());
	public static final RegistryObject<Block> ETHEREAL_STAIRS = REGISTRY.register("ethereal_stairs", () -> new EtherealStairsBlock());
	public static final RegistryObject<Block> ETHEREAL_SLAB = REGISTRY.register("ethereal_slab", () -> new EtherealSlabBlock());
	public static final RegistryObject<Block> ETHEREAL_FENCE = REGISTRY.register("ethereal_fence", () -> new EtherealFenceBlock());
	public static final RegistryObject<Block> ETHEREAL_FENCE_GATE = REGISTRY.register("ethereal_fence_gate", () -> new EtherealFenceGateBlock());
	public static final RegistryObject<Block> ETHEREAL_DOOR = REGISTRY.register("ethereal_door", () -> new EtherealDoorBlock());
	public static final RegistryObject<Block> ETHEREAL_TRAPDOOR = REGISTRY.register("ethereal_trapdoor", () -> new EtherealTrapdoorBlock());
	public static final RegistryObject<Block> ETHEREAL_PRESSURE_PLATE = REGISTRY.register("ethereal_pressure_plate", () -> new EtherealPressurePlateBlock());
	public static final RegistryObject<Block> ETHEREAL_BUTTON = REGISTRY.register("ethereal_button", () -> new EtherealButtonBlock());
	public static final RegistryObject<Block> ETHEREAL_LEAVES = REGISTRY.register("ethereal_leaves", () -> new EtherealLeavesBlock());
	public static final RegistryObject<Block> ROOTED_END_STONE = REGISTRY.register("rooted_end_stone", () -> new RootedEndStoneBlock());
	public static final RegistryObject<Block> ETHEREAL_SAP = REGISTRY.register("ethereal_sap", () -> new EtherealSapBlock());
	public static final RegistryObject<Block> ETHEREAL_SYRUP = REGISTRY.register("ethereal_syrup", () -> new EtherealSyrupBlock());
	public static final RegistryObject<Block> ETHEREAL_CAKE = REGISTRY.register("ethereal_cake", () -> new EtherealCakeBlock());
	public static final RegistryObject<Block> ETHEREAL_GROWTH = REGISTRY.register("ethereal_growth", () -> new EtherealGrowthBlock());
	public static final RegistryObject<Block> HAZARDOUS_HYPHAE_BOTTOM = REGISTRY.register("hazardous_hyphae_bottom", () -> new HazardousHyphaeBottomBlock());
	public static final RegistryObject<Block> LETHAL_LIANA_BOTTOM = REGISTRY.register("lethal_liana_bottom", () -> new LethalLianaBottomBlock());
	public static final RegistryObject<Block> ETHEREAL_CAKE_1 = REGISTRY.register("ethereal_cake_1", () -> new EtherealCake1Block());
	public static final RegistryObject<Block> ETHEREAL_CAKE_2 = REGISTRY.register("ethereal_cake_2", () -> new EtherealCake2Block());
	public static final RegistryObject<Block> ETHEREAL_CAKE_3 = REGISTRY.register("ethereal_cake_3", () -> new EtherealCake3Block());
	public static final RegistryObject<Block> ETHEREAL_CAKE_4 = REGISTRY.register("ethereal_cake_4", () -> new EtherealCake4Block());
	public static final RegistryObject<Block> ETHEREAL_CAKE_5 = REGISTRY.register("ethereal_cake_5", () -> new EtherealCake5Block());
	public static final RegistryObject<Block> ETHEREAL_CAKE_6 = REGISTRY.register("ethereal_cake_6", () -> new EtherealCake6Block());
	public static final RegistryObject<Block> ETHEREAL_BUSH_STAGE_0 = REGISTRY.register("ethereal_bush_stage_0", () -> new EtherealBushStage0Block());
	public static final RegistryObject<Block> ETHEREAL_BUSH_STAGE_1 = REGISTRY.register("ethereal_bush_stage_1", () -> new EtherealBushStage1Block());
	public static final RegistryObject<Block> ETHEREAL_BUSH_STAGE_2 = REGISTRY.register("ethereal_bush_stage_2", () -> new EtherealBushStage2Block());
	public static final RegistryObject<Block> ETHEREAL_BUSH_STAGE_3 = REGISTRY.register("ethereal_bush_stage_3", () -> new EtherealBushStage3Block());
	public static final RegistryObject<Block> LETHAL_LIANA = REGISTRY.register("lethal_liana", () -> new LethalLianaBlock());
	public static final RegistryObject<Block> HAZARDOUS_HYPHAE = REGISTRY.register("hazardous_hyphae", () -> new HazardousHyphaeBlock());
}
