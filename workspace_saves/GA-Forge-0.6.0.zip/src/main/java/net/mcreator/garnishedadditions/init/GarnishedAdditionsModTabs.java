
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

public class GarnishedAdditionsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GarnishedAdditionsMod.MODID);
	public static final RegistryObject<CreativeModeTab> GARNISHED_ADDITIONS = REGISTRY.register("garnished_additions", () -> CreativeModeTab.builder().title(Component.translatable("item_group.garnished_additions.garnished_additions"))
			.icon(() -> new ItemStack(GarnishedAdditionsModItems.MELTED_CINDER_FLOUR_NUT_MIX.get())).displayItems((parameters, tabData) -> {
				tabData.accept(GarnishedAdditionsModItems.SALTED_CASHEW.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_WALNUT.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_ALMOND.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_PECAN.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_PISTACHIO.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_MACADAMIA.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_PEANUT.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_HAZELNUT.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_CHESTNUT.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_CASHEW.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_WALNUT.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_ALMOND.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_PECAN.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_PISTACHIO.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_MACADAMIA.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_PEANUT.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_HAZELNUT.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_CHESTNUT.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_CASHEW.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_WALNUT.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_ALMOND.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_PECAN.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_PISTACHIO.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_MACADAMIA.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_PEANUT.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_HAZELNUT.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_CHESTNUT.get());
				tabData.accept(GarnishedAdditionsModItems.UNGARNISHED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.GARNISHED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.SWEETENED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.CHOCOLATE_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.HONEYED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.CINDER_FLOUR_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.MELTED_CINDER_FLOUR_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.SALTED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.ROASTED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_ROASTED_NUT_MIX.get());
				tabData.accept(GarnishedAdditionsModItems.FRITTELLE.get());
				tabData.accept(GarnishedAdditionsModItems.DUMPLINGS.get());
				tabData.accept(GarnishedAdditionsModItems.CHOCOLATE_NUT_BITES.get());
				tabData.accept(GarnishedAdditionsModItems.PEMMICAN.get());
				tabData.accept(GarnishedAdditionsModItems.BISCOTTI.get());
				tabData.accept(GarnishedAdditionsModItems.BAKEWELL_TART.get());
				tabData.accept(GarnishedAdditionsModItems.WALNUT_LOAF.get());
				tabData.accept(GarnishedAdditionsModItems.MALSOUKA.get());
				tabData.accept(GarnishedAdditionsModItems.MINCE_PIE.get());
				tabData.accept(GarnishedAdditionsModItems.PRALINE.get());
				tabData.accept(GarnishedAdditionsModItems.CHESTNUT_PANCAKE.get());
				tabData.accept(GarnishedAdditionsModItems.MARZIPAN.get());
				tabData.accept(GarnishedAdditionsModItems.CHESTNUT_CAKE.get());
				tabData.accept(GarnishedAdditionsModItems.CHESTNUT_CAKE_SLICE.get());
				tabData.accept(GarnishedAdditionsModItems.DERBY_PIE.get());
				tabData.accept(GarnishedAdditionsModItems.DERBY_PIE_SLICE.get());
				tabData.accept(GarnishedAdditionsModItems.POUND_CAKE.get());
				tabData.accept(GarnishedAdditionsModItems.POUND_CAKE_SLICE.get());
				tabData.accept(GarnishedAdditionsModItems.CHESTNUT_PIE.get());
				tabData.accept(GarnishedAdditionsModItems.CHESTNUT_PIE_SLICE.get());
				tabData.accept(GarnishedAdditionsModItems.CASHEW_PIE.get());
				tabData.accept(GarnishedAdditionsModItems.CASHEW_PIE_SLICE.get());
				tabData.accept(GarnishedAdditionsModItems.WALNUT_PIE.get());
				tabData.accept(GarnishedAdditionsModItems.WALNUT_PIE_SLICE.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_INGOT.get());
				tabData.accept(GarnishedAdditionsModBlocks.NUTIUM_BLOCK.get().asItem());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_SWORD.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_AXE.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_PICKAXE.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_SHOVEL.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_HOE.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_HELMET.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_CHESTPLATE.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_LEGGINGS.get());
				tabData.accept(GarnishedAdditionsModItems.NUTIUM_BOOTS.get());
				tabData.accept(GarnishedAdditionsModItems.MACARON.get());
				tabData.accept(GarnishedAdditionsModItems.YAM_PUFFS.get());
				tabData.accept(GarnishedAdditionsModItems.TRAVELERS_STEW.get());
				tabData.accept(GarnishedAdditionsModItems.PANCAKES.get());
				tabData.accept(GarnishedAdditionsModItems.CHOCOLATE_COVERED_PANCAKES.get());
				tabData.accept(GarnishedAdditionsModItems.HONEY_COVERED_PANCAKES.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_PANCAKES.get());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_LOG.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_WOOD.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.STRIPPED_ETHEREAL_LOG.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.STRIPPED_ETHEREAL_WOOD.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_PLANKS.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_STAIRS.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_SLAB.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_FENCE.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_FENCE_GATE.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_DOOR.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_TRAPDOOR.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_PRESSURE_PLATE.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_BUTTON.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_LEAVES.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ROOTED_END_STONE.get().asItem());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_ROOTS.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_BERRIES.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_FRUIT.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_LEAF.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_SAP_BUCKET.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_SYRUP_BUCKET.get());
				tabData.accept(GarnishedAdditionsModItems.BOTTLE_OF_ETHEREAL_SAP.get());
				tabData.accept(GarnishedAdditionsModItems.BOTTLE_OF_ETHEREAL_SYRUP.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_COCKTAIL.get());
				tabData.accept(GarnishedAdditionsModItems.ETHEREAL_SALAD.get());
				tabData.accept(GarnishedAdditionsModItems.SLICE_OF_ETHEREAL_DELIGHT.get());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_CAKE.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.ETHEREAL_GROWTH.get().asItem());
				tabData.accept(GarnishedAdditionsModItems.PIGLIN_MEAT.get());
				tabData.accept(GarnishedAdditionsModItems.COOKED_PIGLIN.get());
				tabData.accept(GarnishedAdditionsModItems.HOGLIN_MEAT.get());
				tabData.accept(GarnishedAdditionsModItems.COOKED_HOGLIN.get());
				tabData.accept(GarnishedAdditionsModItems.STRIDER_MEAT.get());
				tabData.accept(GarnishedAdditionsModItems.COOKED_STRIDER.get());
				tabData.accept(GarnishedAdditionsModItems.SPICE_COMPOUND.get());
				tabData.accept(GarnishedAdditionsModItems.SPICE_POWDER.get());
				tabData.accept(GarnishedAdditionsModItems.CURSED_CALAMARI.get());
				tabData.accept(GarnishedAdditionsModItems.GHAST_BALLS.get());
				tabData.accept(GarnishedAdditionsModItems.BLAZE_NOODLES.get());
				tabData.accept(GarnishedAdditionsModItems.DANGER_NOODLES.get());
				tabData.accept(GarnishedAdditionsModItems.PIGLIN_STEW.get());
				tabData.accept(GarnishedAdditionsModItems.MAGMA_CUBE_STEW.get());
				tabData.accept(GarnishedAdditionsModItems.SLIME_STEW.get());
				tabData.accept(GarnishedAdditionsModItems.HOT_N_STICKY_STEW.get());
				tabData.accept(GarnishedAdditionsModBlocks.HAZARDOUS_HYPHAE_BOTTOM.get().asItem());
				tabData.accept(GarnishedAdditionsModBlocks.LETHAL_LIANA_BOTTOM.get().asItem());
			})

			.build());
}
