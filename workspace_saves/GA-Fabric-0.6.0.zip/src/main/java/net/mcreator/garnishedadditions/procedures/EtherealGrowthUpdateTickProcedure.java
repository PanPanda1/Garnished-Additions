package net.mcreator.garnishedadditions.procedures;

import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class EtherealGrowthUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double random = 0;
		if (Mth.nextInt(RandomSource.create(), 1, 3) == 1) {
			random = Mth.nextInt(RandomSource.create(), 1, 8);
			if (random == 1) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x - 5, y - 1, z - 3), BlockPos.containing(x - 5, y - 1, z - 3), new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false),
								_serverworld.random, 3);
					}
				}
			}
			if (random == 2) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x + 3, y - 1, z - 5), BlockPos.containing(x + 3, y - 1, z - 5),
								new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
			if (random == 3) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x - 3, y - 1, z + 5), BlockPos.containing(x - 3, y - 1, z + 5),
								new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
			if (random == 4) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x + 5, y - 1, z + 3), BlockPos.containing(x + 5, y - 1, z + 3),
								new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
			if (random == 5) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x + 5, y - 1, z - 3), BlockPos.containing(x + 5, y - 1, z - 3),
								new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.FRONT_BACK).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
			if (random == 6) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x + 3, y - 1, z + 5), BlockPos.containing(x + 3, y - 1, z + 5),
								new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.FRONT_BACK).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
			if (random == 7) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x - 3, y - 1, z - 5), BlockPos.containing(x - 3, y - 1, z - 5),
								new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.FRONT_BACK).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
			if (random == 8) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
				if (world instanceof ServerLevel _serverworld) {
					StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("garnished_additions", "ethereal_tree"));
					if (template != null) {
						template.placeInWorld(_serverworld, BlockPos.containing(x - 5, y - 1, z + 3), BlockPos.containing(x - 5, y - 1, z + 3),
								new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.FRONT_BACK).setIgnoreEntities(false), _serverworld.random, 3);
					}
				}
			}
		}
	}
}
