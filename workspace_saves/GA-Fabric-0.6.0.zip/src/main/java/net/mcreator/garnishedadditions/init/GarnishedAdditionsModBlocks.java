
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.garnishedadditions.block.StrippedEtherealWoodBlock;
import net.mcreator.garnishedadditions.block.StrippedEtherealLogBlock;
import net.mcreator.garnishedadditions.block.RootedEndStoneBlock;
import net.mcreator.garnishedadditions.block.NutiumBlockBlock;
import net.mcreator.garnishedadditions.block.LethalLianaBottomBlock;
import net.mcreator.garnishedadditions.block.LethalLianaBlock;
import net.mcreator.garnishedadditions.block.HazardousHyphaeBottomBlock;
import net.mcreator.garnishedadditions.block.HazardousHyphaeBlock;
import net.mcreator.garnishedadditions.block.EtherealWoodBlock;
import net.mcreator.garnishedadditions.block.EtherealTrapdoorBlock;
import net.mcreator.garnishedadditions.block.EtherealStairsBlock;
import net.mcreator.garnishedadditions.block.EtherealSlabBlock;
import net.mcreator.garnishedadditions.block.EtherealPressurePlateBlock;
import net.mcreator.garnishedadditions.block.EtherealPlanksBlock;
import net.mcreator.garnishedadditions.block.EtherealLogBlock;
import net.mcreator.garnishedadditions.block.EtherealLeavesBlock;
import net.mcreator.garnishedadditions.block.EtherealGrowthBlock;
import net.mcreator.garnishedadditions.block.EtherealFenceGateBlock;
import net.mcreator.garnishedadditions.block.EtherealFenceBlock;
import net.mcreator.garnishedadditions.block.EtherealDoorBlock;
import net.mcreator.garnishedadditions.block.EtherealCakeBlock;
import net.mcreator.garnishedadditions.block.EtherealCake6Block;
import net.mcreator.garnishedadditions.block.EtherealCake5Block;
import net.mcreator.garnishedadditions.block.EtherealCake4Block;
import net.mcreator.garnishedadditions.block.EtherealCake3Block;
import net.mcreator.garnishedadditions.block.EtherealCake2Block;
import net.mcreator.garnishedadditions.block.EtherealCake1Block;
import net.mcreator.garnishedadditions.block.EtherealButtonBlock;
import net.mcreator.garnishedadditions.block.EtherealBushStage3Block;
import net.mcreator.garnishedadditions.block.EtherealBushStage2Block;
import net.mcreator.garnishedadditions.block.EtherealBushStage1Block;
import net.mcreator.garnishedadditions.block.EtherealBushStage0Block;
import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

public class GarnishedAdditionsModBlocks {
	public static Block NUTIUM_BLOCK;
	public static Block ETHEREAL_GROWTH;
	public static Block ETHEREAL_LOG;
	public static Block ETHEREAL_WOOD;
	public static Block STRIPPED_ETHEREAL_LOG;
	public static Block STRIPPED_ETHEREAL_WOOD;
	public static Block ETHEREAL_PLANKS;
	public static Block ETHEREAL_STAIRS;
	public static Block ETHEREAL_SLAB;
	public static Block ETHEREAL_FENCE;
	public static Block ETHEREAL_FENCE_GATE;
	public static Block ETHEREAL_DOOR;
	public static Block ETHEREAL_TRAPDOOR;
	public static Block ETHEREAL_PRESSURE_PLATE;
	public static Block ETHEREAL_BUTTON;
	public static Block ETHEREAL_LEAVES;
	public static Block ROOTED_END_STONE;
	public static Block ETHEREAL_CAKE;
	public static Block HAZARDOUS_HYPHAE_BOTTOM;
	public static Block LETHAL_LIANA_BOTTOM;
	public static Block ETHEREAL_CAKE_1;
	public static Block ETHEREAL_CAKE_2;
	public static Block ETHEREAL_CAKE_3;
	public static Block ETHEREAL_CAKE_4;
	public static Block ETHEREAL_CAKE_5;
	public static Block ETHEREAL_CAKE_6;
	public static Block ETHEREAL_BUSH_STAGE_0;
	public static Block ETHEREAL_BUSH_STAGE_1;
	public static Block ETHEREAL_BUSH_STAGE_2;
	public static Block ETHEREAL_BUSH_STAGE_3;
	public static Block HAZARDOUS_HYPHAE;
	public static Block LETHAL_LIANA;

	public static void load() {
		NUTIUM_BLOCK = register("nutium_block", new NutiumBlockBlock());
		ETHEREAL_GROWTH = register("ethereal_growth", new EtherealGrowthBlock());
		ETHEREAL_LOG = register("ethereal_log", new EtherealLogBlock());
		ETHEREAL_WOOD = register("ethereal_wood", new EtherealWoodBlock());
		STRIPPED_ETHEREAL_LOG = register("stripped_ethereal_log", new StrippedEtherealLogBlock());
		STRIPPED_ETHEREAL_WOOD = register("stripped_ethereal_wood", new StrippedEtherealWoodBlock());
		ETHEREAL_PLANKS = register("ethereal_planks", new EtherealPlanksBlock());
		ETHEREAL_STAIRS = register("ethereal_stairs", new EtherealStairsBlock());
		ETHEREAL_SLAB = register("ethereal_slab", new EtherealSlabBlock());
		ETHEREAL_FENCE = register("ethereal_fence", new EtherealFenceBlock());
		ETHEREAL_FENCE_GATE = register("ethereal_fence_gate", new EtherealFenceGateBlock());
		ETHEREAL_DOOR = register("ethereal_door", new EtherealDoorBlock());
		ETHEREAL_TRAPDOOR = register("ethereal_trapdoor", new EtherealTrapdoorBlock());
		ETHEREAL_PRESSURE_PLATE = register("ethereal_pressure_plate", new EtherealPressurePlateBlock());
		ETHEREAL_BUTTON = register("ethereal_button", new EtherealButtonBlock());
		ETHEREAL_LEAVES = register("ethereal_leaves", new EtherealLeavesBlock());
		ROOTED_END_STONE = register("rooted_end_stone", new RootedEndStoneBlock());
		ETHEREAL_CAKE = register("ethereal_cake", new EtherealCakeBlock());
		HAZARDOUS_HYPHAE_BOTTOM = register("hazardous_hyphae_bottom", new HazardousHyphaeBottomBlock());
		LETHAL_LIANA_BOTTOM = register("lethal_liana_bottom", new LethalLianaBottomBlock());
		ETHEREAL_CAKE_1 = register("ethereal_cake_1", new EtherealCake1Block());
		ETHEREAL_CAKE_2 = register("ethereal_cake_2", new EtherealCake2Block());
		ETHEREAL_CAKE_3 = register("ethereal_cake_3", new EtherealCake3Block());
		ETHEREAL_CAKE_4 = register("ethereal_cake_4", new EtherealCake4Block());
		ETHEREAL_CAKE_5 = register("ethereal_cake_5", new EtherealCake5Block());
		ETHEREAL_CAKE_6 = register("ethereal_cake_6", new EtherealCake6Block());
		ETHEREAL_BUSH_STAGE_0 = register("ethereal_bush_stage_0", new EtherealBushStage0Block());
		ETHEREAL_BUSH_STAGE_1 = register("ethereal_bush_stage_1", new EtherealBushStage1Block());
		ETHEREAL_BUSH_STAGE_2 = register("ethereal_bush_stage_2", new EtherealBushStage2Block());
		ETHEREAL_BUSH_STAGE_3 = register("ethereal_bush_stage_3", new EtherealBushStage3Block());
		HAZARDOUS_HYPHAE = register("hazardous_hyphae", new HazardousHyphaeBlock());
		LETHAL_LIANA = register("lethal_liana", new LethalLianaBlock());
	}

	public static void clientLoad() {
		NutiumBlockBlock.clientInit();
		EtherealGrowthBlock.clientInit();
		EtherealLogBlock.clientInit();
		EtherealWoodBlock.clientInit();
		StrippedEtherealLogBlock.clientInit();
		StrippedEtherealWoodBlock.clientInit();
		EtherealPlanksBlock.clientInit();
		EtherealStairsBlock.clientInit();
		EtherealSlabBlock.clientInit();
		EtherealFenceBlock.clientInit();
		EtherealFenceGateBlock.clientInit();
		EtherealDoorBlock.clientInit();
		EtherealTrapdoorBlock.clientInit();
		EtherealPressurePlateBlock.clientInit();
		EtherealButtonBlock.clientInit();
		EtherealLeavesBlock.clientInit();
		RootedEndStoneBlock.clientInit();
		EtherealCakeBlock.clientInit();
		HazardousHyphaeBottomBlock.clientInit();
		LethalLianaBottomBlock.clientInit();
		EtherealCake1Block.clientInit();
		EtherealCake2Block.clientInit();
		EtherealCake3Block.clientInit();
		EtherealCake4Block.clientInit();
		EtherealCake5Block.clientInit();
		EtherealCake6Block.clientInit();
		EtherealBushStage0Block.clientInit();
		EtherealBushStage1Block.clientInit();
		EtherealBushStage2Block.clientInit();
		EtherealBushStage3Block.clientInit();
		HazardousHyphaeBlock.clientInit();
		LethalLianaBlock.clientInit();
	}

	private static Block register(String registryName, Block block) {
		return Registry.register(BuiltInRegistries.BLOCK, new ResourceLocation(GarnishedAdditionsMod.MODID, registryName), block);
	}
}
