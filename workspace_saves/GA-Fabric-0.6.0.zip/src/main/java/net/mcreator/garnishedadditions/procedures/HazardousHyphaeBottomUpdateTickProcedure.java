package net.mcreator.garnishedadditions.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.garnishedadditions.init.GarnishedAdditionsModBlocks;

import java.util.Map;

public class HazardousHyphaeBottomUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (Math.random() < 0.33333) {
			if ((world.getBlockState(BlockPos.containing(x, y + 20, z))).getBlock() == GarnishedAdditionsModBlocks.HAZARDOUS_HYPHAE) {
				{
					BlockPos _bp = BlockPos.containing(x, y, z);
					BlockState _bs = GarnishedAdditionsModBlocks.HAZARDOUS_HYPHAE_BOTTOM.defaultBlockState();
					BlockState _bso = world.getBlockState(_bp);
					for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
						Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
						if (_property != null && _bs.getValue(_property) != null)
							try {
								_bs = _bs.setValue(_property, (Comparable) entry.getValue());
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp, _bs, 3);
				}
			} else {
				if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == Blocks.AIR && !((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() instanceof LiquidBlock)) {
					{
						BlockPos _bp = BlockPos.containing(x, y, z);
						BlockState _bs = GarnishedAdditionsModBlocks.HAZARDOUS_HYPHAE.defaultBlockState();
						BlockState _bso = world.getBlockState(_bp);
						for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
							Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
							if (_property != null && _bs.getValue(_property) != null)
								try {
									_bs = _bs.setValue(_property, (Comparable) entry.getValue());
								} catch (Exception e) {
								}
						}
						world.setBlock(_bp, _bs, 3);
					}
					world.setBlock(BlockPos.containing(x, y - 1, z), GarnishedAdditionsModBlocks.HAZARDOUS_HYPHAE_BOTTOM.defaultBlockState(), 3);
				}
			}
		}
	}
}
