
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.garnishedadditions.block.entity.EtherealBushStage3BlockEntity;
import net.mcreator.garnishedadditions.block.entity.EtherealBushStage2BlockEntity;
import net.mcreator.garnishedadditions.block.entity.EtherealBushStage1BlockEntity;
import net.mcreator.garnishedadditions.block.entity.EtherealBushStage0BlockEntity;
import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

public class GarnishedAdditionsModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, GarnishedAdditionsMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> ETHEREAL_BUSH_STAGE_0 = register("ethereal_bush_stage_0", GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_0, EtherealBushStage0BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ETHEREAL_BUSH_STAGE_1 = register("ethereal_bush_stage_1", GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_1, EtherealBushStage1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ETHEREAL_BUSH_STAGE_2 = register("ethereal_bush_stage_2", GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_2, EtherealBushStage2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ETHEREAL_BUSH_STAGE_3 = register("ethereal_bush_stage_3", GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_3, EtherealBushStage3BlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
