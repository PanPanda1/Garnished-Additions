
package net.mcreator.garnishedadditions.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.garnishedadditions.init.GarnishedAdditionsModItems;
import net.mcreator.garnishedadditions.init.GarnishedAdditionsModFluids;
import net.mcreator.garnishedadditions.init.GarnishedAdditionsModFluidTypes;
import net.mcreator.garnishedadditions.init.GarnishedAdditionsModBlocks;

public abstract class EtherealSapFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> GarnishedAdditionsModFluidTypes.ETHEREAL_SAP_TYPE.get(), () -> GarnishedAdditionsModFluids.ETHEREAL_SAP.get(),
			() -> GarnishedAdditionsModFluids.FLOWING_ETHEREAL_SAP.get()).explosionResistance(100f).tickRate(30).levelDecreasePerBlock(2).slopeFindDistance(3).bucket(() -> GarnishedAdditionsModItems.ETHEREAL_SAP_BUCKET.get())
			.block(() -> (LiquidBlock) GarnishedAdditionsModBlocks.ETHEREAL_SAP.get());

	private EtherealSapFluid() {
		super(PROPERTIES);
	}

	public static class Source extends EtherealSapFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends EtherealSapFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
