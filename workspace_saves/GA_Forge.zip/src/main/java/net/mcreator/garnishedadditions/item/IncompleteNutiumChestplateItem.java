
package net.mcreator.garnishedadditions.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class IncompleteNutiumChestplateItem extends Item {
	public IncompleteNutiumChestplateItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
