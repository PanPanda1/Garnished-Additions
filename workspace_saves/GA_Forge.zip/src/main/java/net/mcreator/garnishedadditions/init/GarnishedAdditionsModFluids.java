
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.garnishedadditions.fluid.EtherealSyrupFluid;
import net.mcreator.garnishedadditions.fluid.EtherealSapFluid;
import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

public class GarnishedAdditionsModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, GarnishedAdditionsMod.MODID);
	public static final RegistryObject<FlowingFluid> ETHEREAL_SAP = REGISTRY.register("ethereal_sap", () -> new EtherealSapFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_ETHEREAL_SAP = REGISTRY.register("flowing_ethereal_sap", () -> new EtherealSapFluid.Flowing());
	public static final RegistryObject<FlowingFluid> ETHEREAL_SYRUP = REGISTRY.register("ethereal_syrup", () -> new EtherealSyrupFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_ETHEREAL_SYRUP = REGISTRY.register("flowing_ethereal_syrup", () -> new EtherealSyrupFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(ETHEREAL_SAP.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ETHEREAL_SAP.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(ETHEREAL_SYRUP.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ETHEREAL_SYRUP.get(), RenderType.translucent());
		}
	}
}
