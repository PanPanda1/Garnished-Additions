
package net.mcreator.garnishedadditions.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EtherealEssenceItem extends Item {
	public EtherealEssenceItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
