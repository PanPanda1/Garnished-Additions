
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber
public class GarnishedAdditionsModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == GarnishedAdditionsModItems.BIOFUEL.get())
			event.setBurnTime(1800);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.NUT_POWDER.get())
			event.setBurnTime(1200);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.STARDUST.get())
			event.setBurnTime(3000);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.STELLAR_HUSK.get())
			event.setBurnTime(3000);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.STELLAR_CORE.get())
			event.setBurnTime(3000);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.IRONNUT.get())
			event.setBurnTime(3600);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.IRONNUT_POWDER.get())
			event.setBurnTime(2400);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.ETHEREAL_ESSENCE.get())
			event.setBurnTime(3000);
		else if (itemstack.getItem() == GarnishedAdditionsModItems.ULTRADENSE_FUEL.get())
			event.setBurnTime(2000);
	}
}
