
package net.mcreator.garnishedadditions.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.garnishedadditions.init.GarnishedAdditionsModFluids;

public class EtherealSyrupItem extends BucketItem {
	public EtherealSyrupItem() {
		super(GarnishedAdditionsModFluids.ETHEREAL_SYRUP, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
