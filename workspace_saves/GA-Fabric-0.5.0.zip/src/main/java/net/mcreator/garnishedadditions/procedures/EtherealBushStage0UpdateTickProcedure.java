package net.mcreator.garnishedadditions.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

import net.mcreator.garnishedadditions.init.GarnishedAdditionsModBlocks;

public class EtherealBushStage0UpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (Mth.nextInt(RandomSource.create(), 1, 3) == 1) {
			world.setBlock(BlockPos.containing(x, y, z), GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_1.defaultBlockState(), 3);
		}
	}
}
