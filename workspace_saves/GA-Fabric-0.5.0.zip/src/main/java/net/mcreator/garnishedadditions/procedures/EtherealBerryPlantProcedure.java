package net.mcreator.garnishedadditions.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.garnishedadditions.init.GarnishedAdditionsModItems;
import net.mcreator.garnishedadditions.init.GarnishedAdditionsModBlocks;

public class EtherealBerryPlantProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == GarnishedAdditionsModItems.ETHEREAL_BERRIES
				&& (Blocks.END_STONE == (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() || GarnishedAdditionsModBlocks.ROOTED_END_STONE == (world.getBlockState(BlockPos.containing(x, y, z))).getBlock())) {
			if (Blocks.AIR == (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock()) {
				itemstack.shrink(1);
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("item.crop.plant")), SoundSource.BLOCKS, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("item.crop.plant")), SoundSource.BLOCKS, 1, 1, false);
					}
				}
				world.setBlock(BlockPos.containing(x, y + 1, z), GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_0.defaultBlockState(), 3);
			}
		}
	}
}
