
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.mcreator.garnishedadditions.procedures.RootedEndStoneOnBlockRightClickedProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealWoodOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealLogOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealLeavesOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealGrowthUpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealCakeOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage3OnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage2UpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage2OnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage1UpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage0UpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushBoneMealProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBerryPlantProcedure;
import net.mcreator.garnishedadditions.procedures.BoneMealOnEtherealGrowthProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class GarnishedAdditionsModProcedures {
	public static void load() {
		new EtherealWoodOnRightClickProcedure();
		new RootedEndStoneOnBlockRightClickedProcedure();
		new EtherealLogOnRightClickProcedure();
		new EtherealGrowthUpdateTickProcedure();
		new EtherealBerryPlantProcedure();
		new EtherealBushStage0UpdateTickProcedure();
		new EtherealBushStage1UpdateTickProcedure();
		new EtherealBushStage2UpdateTickProcedure();
		new EtherealBushBoneMealProcedure();
		new EtherealBushStage3OnRightClickProcedure();
		new EtherealBushStage2OnRightClickProcedure();
		new EtherealCakeOnRightClickProcedure();
		new EtherealLeavesOnRightClickProcedure();
		new BoneMealOnEtherealGrowthProcedure();
	}
}
