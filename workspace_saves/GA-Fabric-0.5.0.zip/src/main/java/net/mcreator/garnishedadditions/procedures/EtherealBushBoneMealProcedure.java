package net.mcreator.garnishedadditions.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.garnishedadditions.init.GarnishedAdditionsModBlocks;

public class EtherealBushBoneMealProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.BONE_MEAL && (GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_0 == (world.getBlockState(BlockPos.containing(x, y, z))).getBlock()
				|| GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_1 == (world.getBlockState(BlockPos.containing(x, y, z))).getBlock())) {
			itemstack.shrink(1);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("item.bone_meal.use")), SoundSource.BLOCKS, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(new ResourceLocation("item.bone_meal.use")), SoundSource.BLOCKS, 1, 1, false);
				}
			}
			world.setBlock(BlockPos.containing(x, y, z), GarnishedAdditionsModBlocks.ETHEREAL_BUSH_STAGE_2.defaultBlockState(), 3);
		}
	}
}
