
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraft.world.level.levelgen.feature.configurations.RandomPatchConfiguration;
import net.minecraft.world.level.levelgen.feature.RandomPatchFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.garnishedadditions.block.EtherealGrowthBlock;
import net.mcreator.garnishedadditions.block.EtherealBushPlantBlock;
import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;

import java.util.function.Predicate;

public class GarnishedAdditionsModFeatures {
	public static void load() {
		register("ethereal_growth", new RandomPatchFeature(RandomPatchConfiguration.CODEC), EtherealGrowthBlock.GENERATE_BIOMES, GenerationStep.Decoration.VEGETAL_DECORATION);
		register("ethereal_bush_plant", new RandomPatchFeature(RandomPatchConfiguration.CODEC), EtherealBushPlantBlock.GENERATE_BIOMES, GenerationStep.Decoration.VEGETAL_DECORATION);
	}

	public static void register(String registryName, Feature feature, Predicate<BiomeSelectionContext> biomes, GenerationStep.Decoration genStep) {
		Registry.register(BuiltInRegistries.FEATURE, new ResourceLocation(GarnishedAdditionsMod.MODID, registryName), feature);
		BiomeModifications.addFeature(biomes, genStep, ResourceKey.create(Registries.PLACED_FEATURE, new ResourceLocation(GarnishedAdditionsMod.MODID, registryName)));
	}
}
