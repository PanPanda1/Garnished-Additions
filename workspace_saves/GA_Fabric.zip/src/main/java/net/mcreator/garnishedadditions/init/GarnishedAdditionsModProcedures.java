
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.mcreator.garnishedadditions.procedures.RootedEndStoneOnBlockRightClickedProcedure;
import net.mcreator.garnishedadditions.procedures.LethalLianaBottomUpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.LethalLianaBottomOnBoneMealSuccessProcedureProcedure;
import net.mcreator.garnishedadditions.procedures.LethalLianaBottomAdditionalPlacinggrowthConditionProcedure;
import net.mcreator.garnishedadditions.procedures.LethalLianaAdditionalPlacinggrowthConditionProcedure;
import net.mcreator.garnishedadditions.procedures.HazardousHyphaeBottomUpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.HazardousHyphaeBottomOnBoneMealSuccessProcedureProcedure;
import net.mcreator.garnishedadditions.procedures.HazardousHyphaeBottomAdditionalPlacinggrowthConditionProcedure;
import net.mcreator.garnishedadditions.procedures.HazardousHyphaeAdditionalPlacinggrowthConditionProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealWoodOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealLogOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealLeavesOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealGrowthUpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealCakeOnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushUpdateTickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage3OnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBushStage2OnRightClickProcedure;
import net.mcreator.garnishedadditions.procedures.EtherealBerryPlantProcedure;
import net.mcreator.garnishedadditions.procedures.BoneMealOnEtherealGrowthProcedure;
import net.mcreator.garnishedadditions.procedures.BoneMealOnEtherealBushProcedure;
import net.mcreator.garnishedadditions.procedures.BiocharRightclickedOnBlockProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class GarnishedAdditionsModProcedures {
	public static void load() {
		new EtherealWoodOnRightClickProcedure();
		new RootedEndStoneOnBlockRightClickedProcedure();
		new EtherealGrowthUpdateTickProcedure();
		new EtherealBerryPlantProcedure();
		new EtherealBushStage3OnRightClickProcedure();
		new EtherealCakeOnRightClickProcedure();
		new BoneMealOnEtherealGrowthProcedure();
		new EtherealLogOnRightClickProcedure();
		new EtherealLeavesOnRightClickProcedure();
		new EtherealBushUpdateTickProcedure();
		new EtherealBushStage2OnRightClickProcedure();
		new BoneMealOnEtherealBushProcedure();
		new HazardousHyphaeBottomAdditionalPlacinggrowthConditionProcedure();
		new HazardousHyphaeBottomUpdateTickProcedure();
		new HazardousHyphaeAdditionalPlacinggrowthConditionProcedure();
		new HazardousHyphaeBottomOnBoneMealSuccessProcedureProcedure();
		new LethalLianaAdditionalPlacinggrowthConditionProcedure();
		new LethalLianaBottomAdditionalPlacinggrowthConditionProcedure();
		new LethalLianaBottomUpdateTickProcedure();
		new LethalLianaBottomOnBoneMealSuccessProcedureProcedure();
		new BiocharRightclickedOnBlockProcedure();
	}
}
