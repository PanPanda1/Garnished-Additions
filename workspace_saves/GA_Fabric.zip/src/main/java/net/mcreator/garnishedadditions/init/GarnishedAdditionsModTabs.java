
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.garnishedadditions.GarnishedAdditionsMod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class GarnishedAdditionsModTabs {
	public static ResourceKey<CreativeModeTab> TAB_GARNISHED_ADDITIONS = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(GarnishedAdditionsMod.MODID, "garnished_additions"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_GARNISHED_ADDITIONS,
				FabricItemGroup.builder().title(Component.translatable("item_group." + GarnishedAdditionsMod.MODID + ".garnished_additions")).icon(() -> new ItemStack(GarnishedAdditionsModItems.MELTED_CINDER_FLOUR_NUT_MIX)).build());
	}
}
