
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.garnishedadditions.init;

import net.fabricmc.fabric.api.registry.FuelRegistry;

public class GarnishedAdditionsModItemExtensions {
	public static void load() {
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.BIOFUEL, 1800);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.NUT_POWDER, 1200);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.STARDUST, 3000);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.STELLAR_HUSK, 3000);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.STELLAR_CORE, 3000);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.IRONNUT, 3600);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.IRONNUT_POWDER, 2400);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.ETHEREAL_ESSENCE, 3000);
		FuelRegistry.INSTANCE.add(GarnishedAdditionsModItems.ULTRADENSE_FUEL, 2000);
	}
}
